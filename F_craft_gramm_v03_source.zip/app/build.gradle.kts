plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.fcraftergram"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.fcraftergram"
        minSdk = 23
        targetSdk = 28
        versionCode = 3
        versionName = "0.3-preview"
    }
}
