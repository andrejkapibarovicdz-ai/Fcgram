package com.fcraftergram.telegram

/**
 * Application-facing contract for the official TDLib adapter.
 *
 * This contract deliberately has no fake network implementation. The real adapter
 * can be added after the official TDLib Android Java/JNI artifacts are built and
 * placed in the app module.
 */
interface TelegramEngine {
    fun start(listener: Listener)
    fun sendPhoneNumber(phoneNumber: String)
    fun checkAuthenticationCode(code: String)
    fun checkAuthenticationPassword(password: String)
    fun loadChats(limit: Int = 50)
    fun sendText(chatId: Long, text: String)
    fun close()

    interface Listener {
        fun onStateChanged(state: AuthState)
        fun onChatsChanged(chats: List<TelegramChat>)
        fun onError(message: String)
    }
}

sealed class AuthState {
    object TdLibMissing : AuthState()
    object WaitingForParameters : AuthState()
    object WaitingForPhoneNumber : AuthState()
    object WaitingForCode : AuthState()
    object WaitingForPassword : AuthState()
    object Ready : AuthState()
    data class Failed(val reason: String) : AuthState()
}

data class TelegramChat(
    val id: Long,
    val title: String,
    val lastMessage: String,
    val unreadCount: Int = 0
)
