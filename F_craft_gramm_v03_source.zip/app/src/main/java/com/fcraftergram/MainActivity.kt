package com.fcraftergram

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val blue = Color.rgb(82, 158, 198)
    private val dark = Color.rgb(45, 45, 45)
    private val muted = Color.rgb(135, 135, 135)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(55, 135, 177)
        window.navigationBarColor = Color.BLACK
        showChats()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showChats() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val toolbar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            setBackgroundColor(blue)
        }
        val title = TextView(this).apply {
            text = "F_craft_gramm"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        toolbar.addView(title, LinearLayout.LayoutParams(0, dp(56), 1f))
        val search = TextView(this).apply {
            text = "⌕"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        toolbar.addView(search, LinearLayout.LayoutParams(dp(44), dp(56)))
        root.addView(toolbar)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(70, 145, 184))
        }
        listOf("ВСЕ ЧАТЫ", "ЛИЧНЫЕ", "ГРУППЫ").forEachIndexed { index, label ->
            val tab = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(0, dp(14), 0, dp(14))
                if (index == 0) setTypeface(null, Typeface.BOLD)
            }
            tabs.addView(tab, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(tabs)

        val previewNotice = TextView(this).apply {
            text = "ПРЕДПРОСМОТР · TDLib ещё не подключена"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(105, 85, 35))
            setBackgroundColor(Color.rgb(255, 247, 220))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(previewNotice)

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val demo = listOf(
            Triple("Telegram", "Добро пожаловать в F_craft_gramm", "✓"),
            Triple("Избранное", "Заметки и сохранённые сообщения", "★"),
            Triple("Новости", "Здесь будут ваши каналы", "N"),
            Triple("Друзья", "Ваши личные переписки появятся здесь", "D")
        )
        demo.forEach { (name, message, symbol) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(9), dp(14), dp(9))
                setBackgroundColor(Color.WHITE)
            }
            val avatar = TextView(this).apply {
                text = symbol
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setBackgroundColor(blue)
            }
            row.addView(avatar, LinearLayout.LayoutParams(dp(50), dp(50)))
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            texts.addView(TextView(this).apply {
                text = name; textSize = 16f; setTextColor(dark)
                typeface = Typeface.DEFAULT_BOLD
            })
            texts.addView(TextView(this).apply {
                text = message; textSize = 13f; setTextColor(muted)
                maxLines = 1
            })
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnClickListener {
                Toast.makeText(
                    this,
                    "Это демонстрационный элемент. Подключение TDLib будет следующим этапом.",
                    Toast.LENGTH_LONG
                ).show()
            }
            list.addView(row, LinearLayout.LayoutParams(-1, dp(70)))
            list.addView(View(this).apply {
                setBackgroundColor(Color.rgb(235, 235, 235))
            }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = TextView(this).apply {
            text = "✉    Чаты                         ⚙    Настройки"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setPadding(0, dp(15), 0, dp(15))
        }
        root.addView(bottom)
        setContentView(root)
    }
}
